import { NavLink } from "react-router-dom";
import { useLocation } from "react-router";
import styled from "@emotion/styled";

interface IProps {
  headerRoutes: Array<{
    path: string;
    name: string;
  }>;
}

const BaseHeader = ({ headerRoutes }: IProps) => {
  const location = useLocation();
  const { pathname } = location;

  // handle check className is active or pending of NavLink
  const classStatusLink = ({ isActive, isPending }: { isActive: boolean; isPending: boolean }) => {
    if (isPending) {
      return "pending";
    }
    if (isActive) {
      return "active";
    }
    return "";
  };

  return (
    <StyledHeader className="base-layout-header">
      <nav>
        <ul>
          {headerRoutes.map((route) => (
            <li key={route.path} className={pathname === route.path ? "active" : ""}>
              <StyledNavLink
                to={route.path}
                className={({ isActive, isPending }) => classStatusLink({ isActive, isPending })}
              >
                {route.name}
              </StyledNavLink>
            </li>
          ))}
        </ul>
      </nav>
    </StyledHeader>
  );
};

const StyledHeader = styled.header`
  background-color: #fff;
  border-bottom: 1px solid #ddd;
  padding: 0 20px;
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  padding: 20px 15px;

  nav {
    ul {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;

      li {
        margin-right: 20px;

        &:last-child {
          margin-right: 0;
        }
      }
    }
  }
`;

const StyledNavLink = styled(NavLink)`
  &.active {
    color: red;
  }
`;

export default BaseHeader;
