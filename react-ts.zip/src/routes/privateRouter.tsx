import { Navigate, useLocation } from "react-router-dom";
import { ReactNode } from "react";

import { useSelector } from "react-redux";
import { RootState } from "@/stores/store";

interface Props {
  children: ReactNode;
}

const PrivateRouter = ({ children }: Props) => {
  const { pathname } = useLocation();
  const { userName } = useSelector((state: RootState) => state.userStore);

  // Implement your own logic here
  if (!userName) {
    return <Navigate to={`/login?redirectFrom=${pathname}`} replace />;
  }

  return children;
};

export default PrivateRouter;
