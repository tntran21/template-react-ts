export const ROUTER_PATH = {
  ROOT: "/",
  HOME: "/",
  ABOUT: "/about",
  LOGIN: "/login",
  NOT_FOUND: "*",
} as const;
