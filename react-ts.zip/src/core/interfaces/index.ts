/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * ## Any Type
 * Any type is a type that represents any value, no specific type.
 */
type TAnyType = any;

interface IResponse<T> {
  data: T;
  status_code: number;
  message: string;
}

interface IResponseError {
  status_code: number;
  message: string;
}

export type { TAnyType, IResponse, IResponseError };
