import AppRouter from "@/routes";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";

import { store } from "./stores/store";

function App() {
  return (
    <Router>
      <Provider store={store}>
        <AppRouter />
      </Provider>
    </Router>
  );
}

export default App;
