import { useNavigate } from "react-router-dom";
import { useCommon } from "@/core/hooks/useCommon";
import { useDispatch } from "react-redux";
import { setUserName } from "@/stores/userSlice";

function LoginPage() {
  const navigate = useNavigate();
  const { query } = useCommon();

  const dispatch = useDispatch();

  const login = () => {
    dispatch(setUserName("test"));
    const redirectFrom = query.get("redirectFrom") ?? "/";
    navigate(redirectFrom);
  };
  return (
    <>
      <div>Login</div>
      <button onClick={() => login()}>login</button>
    </>
  );
}

export default LoginPage;
