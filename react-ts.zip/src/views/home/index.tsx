import { useReduxSelector, useReduxDispatch } from "@/core/hooks/useRedux";
import { setLoading } from "@/stores/appSlice";

/**
 * ## HomePage
 * @path src\views\Home\index.tsx
 * @router /home
 * @returns
 */
function HomePage() {
  const { loading } = useReduxSelector("appStore");
  const disptach = useReduxDispatch();

  const handleChangeStatus = () => {
    disptach(setLoading(!loading));
  };

  return (
    <div>
      <div>HomePage: {loading ? "loading" : "off"}</div>
      <button onClick={() => handleChangeStatus()}>set loading</button>
    </div>
  );
}

HomePage.pageProps = {
  title: "HomPage haha",
  isMask: true,
};

export default HomePage;
