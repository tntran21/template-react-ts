const AboutPage = () => {
  return <div>AboutPage</div>;
};

AboutPage.pageProps = {
  isMask: false,
  title: "AboutPage haha",
};

export default AboutPage;
