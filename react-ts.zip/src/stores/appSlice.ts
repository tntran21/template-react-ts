import { PayloadAction, createSlice } from "@reduxjs/toolkit";

interface AppState {
  loading: boolean;
}

const initState: AppState = {
  loading: false,
};

/**
 * Create a slice for the app state
 */
export const appSlice = createSlice({
  name: "app",
  initialState: initState,
  reducers: {
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
  },
});

/**
 * Export actions
 *
 * @param state
 * @returns
 *
 * @example
 * import { useDispatch } from "react-redux";
 * import { setLoading } from "stores/appSlice";
 *
 * const dispatch = useDispatch();
 * dispatch(setLoading(true));
 * dispatch(setLoading(false));
 * */
export const { setLoading } = appSlice.actions;

export default appSlice.reducer;
