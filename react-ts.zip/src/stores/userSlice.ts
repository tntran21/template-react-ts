import { PayloadAction, createSlice } from "@reduxjs/toolkit";

interface State {
  userName?: string;
}

const initState: State = {
  userName: undefined,
};

// Create a slice for the user state
export const userSlice = createSlice({
  name: "user",
  initialState: initState,
  reducers: {
    setUserName: (state, action: PayloadAction<string>) => {
      state.userName = action.payload;
    },
  },
});

// Export actions
export const { setUserName } = userSlice.actions;

export default userSlice.reducer;
